import './assets/index.ts-CRxPjcUy.js';
